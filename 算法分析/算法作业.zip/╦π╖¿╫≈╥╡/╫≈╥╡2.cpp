#include<stdio.h>
#include<math.h>
#include<algorithm>
#define INF 1e10
#define maxN 100
using namespace std;
int n,qu1[maxN];
struct Node{
	double x;
	double y;	
}qu[maxN];
int cmpx(Node x1,Node x2){
	return x1.x<x2.x;
}
int cmpy(int x1,int x2){
	return qu[qu1[x1]].y<qu[qu1[x2]].y;
}
double calc(int x1,int x2){
	return sqrt(qu[x1].x*qu[x1].x+qu[x2].y+qu[x2].y);
}
double fenzhi(int l,int r){
	if(l>=r) return INF;
	int m=(l+r)>>1,cnt=0;
	double mmin=min(fenzhi(l,m),fenzhi(m+1,r));
	for(int i=m;i>=l;--i){
		if(qu[m].x-qu[i].x<mmin){
			qu1[cnt++]=i;
		}
		else break;
	}
	for(int i=m+1;i<=r;i++){
		if(qu[i].x-qu[m].x<mmin){
			qu1[cnt++]=i;
		}
		else break;
	}
	sort(qu1,qu1+cnt,cmpy);
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(qu[qu1[j]].y-qu[qu1[i]].y<mmin)
				mmin=min(mmin,calc(qu1[i],qu1[j]));
			else break;
		}
	}
	return mmin;
}
int main()
{
	printf("����Ҫ�����ĸ���\n");
	scanf("%d",&n);
	printf("�����Ե�����ֵ:\n");
	for(int i=0;i<n;i++)
		scanf("%lf %lf",&qu[i].x,&qu[i].y);
	sort(qu,qu+n,cmpx);
	printf("��С��Ծ���Ϊ��%.2lf\n",fenzhi(0,n-1));
	return 0;
}
